CREATE DATABASE BikeShopDB;
USE BikeShopDB;

-- Create Supplier table
CREATE TABLE Supplier (
    SupplierID INT PRIMARY KEY,
    SupplierName VARCHAR(100),
    ContactPerson VARCHAR(100),
    PhoneNumber VARCHAR(20),
    Email VARCHAR(100),
    Address VARCHAR(150)
);

-- Create Product table
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    SupplierID INT,
    Price DECIMAL(10, 2),
    QuantityOnHand INT,
    ReorderLevel INT,
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);

-- Insert sample data into Supplier table
INSERT INTO Supplier VALUES
(1, 'BikeWorld Inc.', 'Anna Reed', '555-1001', 'anna@bikeworld.com', '100 1st St, San Francisco, CA'),
(2, 'CycleHub Co.', 'Jake Tran', '555-1002', 'jake@cyclehub.com', '101 2nd St, San Francisco, CA'),
(3, 'PedalPros Ltd.', 'Leah Martinez', '555-1003', 'leah@pedalpros.com', '45 Castro St, San Francisco, CA'),
(4, 'Urban Riders Supply', 'Ben Chow', '555-1004', 'ben@urbanriders.com', '12 Market St, San Francisco, CA'),
(5, 'TrailTech Gear', 'Serena Lopez', '555-1005', 'serena@trailtech.com', '200 Mission St, San Francisco, CA'),
(6, 'KidsOnWheels', 'Joe Kim', '555-1006', 'joe@kidsonwheels.com', '77 Sunset Blvd, San Francisco, CA'),
(7, 'AllSeason Bikes', 'Ella Brown', '555-1007', 'ella@allseasonbikes.com', '123 Haight St, San Francisco, CA'),
(8, 'GreenMotion Supply', 'Ryan Green', '555-1008', 'ryan@greenmotion.com', '333 Divisadero St, SF, CA'),
(9, 'Velocity Parts Co.', 'Matt Davis', '555-1009', 'matt@velocityparts.com', '888 Howard St, San Francisco, CA'),
(10, 'FastLane Cycling', 'Chloe Young', '555-1010', 'chloe@fastlanecycling.com', '9 Lombard St, San Francisco, CA');

-- Insert sample data into Product table
INSERT INTO Product VALUES
(101, 'Lightning Road X', 'Road', 1, 1200, 6, 5),
(102, 'TrailBlazer MTB', 'Mountain', 2, 800, 4, 6),
(103, 'Comet Cruiser', 'Leisure', 3, 450, 10, 4),
(104, 'Hybrid Motion 2', 'Hybrid', 4, 650, 3, 5),
(105, 'Speedster Road Pro', 'Road', 1, 1350, 2, 4),
(106, 'Mountain Climber XT', 'Mountain', 2, 950, 5, 6),
(107, 'Leisure Rider', 'Leisure', 5, 400, 9, 3),
(108, 'Lil’ Wheels KidBike', 'Children’s', 6, 300, 2, 5),
(109, 'Mini Racer', 'Children’s', 6, 320, 8, 3),
(110, 'GreenPath Hybrid', 'Hybrid', 8, 700, 7, 6),
(111, 'Urban Commuter', 'Hybrid', 4, 620, 2, 4),
(112, 'Mountain Max Pro', 'Mountain', 9, 1100, 3, 5),
(113, 'Breeze Leisure', 'Leisure', 3, 480, 6, 4),
(114, 'RoadJet Elite', 'Road', 10, 1400, 1, 3),
(115, 'Trail Runner 3000', 'Mountain', 2, 875, 0, 5);

SELECT ProductName, Price, QuantityOnHand
FROM Product
ORDER BY Price DESC
LIMIT 5;

SELECT s.SupplierName, p.ProductName, p.QuantityOnHand, p.ReorderLevel
FROM Product p
JOIN Supplier s ON p.SupplierID = s.SupplierID
ORDER BY s.SupplierName, p.ProductName;

SELECT p.ProductName, p.QuantityOnHand, p.ReorderLevel, s.SupplierName, s.PhoneNumber, s.Email
FROM Product p
JOIN Supplier s ON p.SupplierID = s.SupplierID
WHERE p.QuantityOnHand < p.ReorderLevel;
